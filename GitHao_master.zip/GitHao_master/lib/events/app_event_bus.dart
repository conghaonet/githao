import 'package:event_bus/event_bus.dart';

export 'package:event_bus/event_bus.dart';
EventBus eventBus = EventBus();