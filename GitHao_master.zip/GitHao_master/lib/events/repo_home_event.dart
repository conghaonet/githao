class RepoHomeTabChangedEvent {
  int tabIndex;
  RepoHomeTabChangedEvent(this.tabIndex);
}