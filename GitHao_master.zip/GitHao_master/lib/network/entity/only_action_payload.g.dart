// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'only_action_payload.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

OnlyActionPayload _$OnlyActionPayloadFromJson(Map<String, dynamic> json) {
  return OnlyActionPayload(
    json['action'] as String,
  );
}

Map<String, dynamic> _$OnlyActionPayloadToJson(OnlyActionPayload instance) =>
    <String, dynamic>{
      'action': instance.action,
    };
