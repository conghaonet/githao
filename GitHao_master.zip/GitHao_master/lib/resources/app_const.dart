class AppConst {
  static const double TAB_HEIGHT = 48;
}