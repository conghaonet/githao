class WebViewPageArgs {
  final String url;
  final String title;

  WebViewPageArgs({this.url, this.title,});

}